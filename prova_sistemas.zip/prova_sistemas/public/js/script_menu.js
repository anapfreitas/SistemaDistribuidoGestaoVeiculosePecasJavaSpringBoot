function montar_Menu() {
	$("#div_Menu").load("nav_bar.html");
}
