package com.sd.apsf_prova_2_serv_gestor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApsfProva2ServGestorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApsfProva2ServGestorApplication.class, args);
	}

}
