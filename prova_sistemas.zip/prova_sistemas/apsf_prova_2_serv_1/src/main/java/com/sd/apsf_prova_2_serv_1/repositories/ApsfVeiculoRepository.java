package com.sd.apsf_prova_2_serv_1.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sd.apsf_prova_2_serv_1.models.ApsfVeiculo;

public interface ApsfVeiculoRepository extends JpaRepository<ApsfVeiculo, Long> {

}
