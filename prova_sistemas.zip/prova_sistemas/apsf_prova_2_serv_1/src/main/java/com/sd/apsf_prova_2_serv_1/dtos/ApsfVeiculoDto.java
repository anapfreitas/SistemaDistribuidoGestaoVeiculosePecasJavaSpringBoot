package com.sd.apsf_prova_2_serv_1.dtos;

public record ApsfVeiculoDto(Long apsf_IdVeiculo, String apsf_Nome, String apsf_Modelo, String apsf_Marca,
		Integer apsf_Ano) {

}
