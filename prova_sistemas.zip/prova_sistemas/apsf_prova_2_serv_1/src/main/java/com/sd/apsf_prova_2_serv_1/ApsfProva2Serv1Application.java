package com.sd.apsf_prova_2_serv_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApsfProva2Serv1Application {

	public static void main(String[] args) {
		SpringApplication.run(ApsfProva2Serv1Application.class, args);
	}

}
