package com.sd.apsf_prova_2_serv_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApsfProva2Serv1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
