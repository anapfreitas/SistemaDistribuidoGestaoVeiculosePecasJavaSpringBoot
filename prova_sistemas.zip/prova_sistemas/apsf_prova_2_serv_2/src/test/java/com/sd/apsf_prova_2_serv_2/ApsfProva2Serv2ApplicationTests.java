package com.sd.apsf_prova_2_serv_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApsfProva2Serv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
