package com.sd.apsf_prova_2_serv_2.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sd.apsf_prova_2_serv_2.models.ApsfPeca;

public interface ApsfPecaRepository extends JpaRepository<ApsfPeca, Long> {
}
