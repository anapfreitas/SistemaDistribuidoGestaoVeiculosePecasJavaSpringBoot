package com.sd.apsf_prova_2_serv_2.dtos;

public record ApsfVeiculoPeca(Long apsf_IdVeiculo, Long apsf_IdPeca, String apsf_Quantidade) {

}
